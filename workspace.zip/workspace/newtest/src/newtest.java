import java.util.TreeMap;


public class newtest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<String,String> t=new TreeMap();
	}

}
